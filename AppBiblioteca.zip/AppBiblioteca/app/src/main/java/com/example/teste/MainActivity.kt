package com.example.teste

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val btncadastrolivro = findViewById<Button>(R.id.cadastrolivro)
        btncadastrolivro.setOnClickListener{
            Toast.makeText(this,"Você clicou no Cadastro de Livros.", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LivroActivity::class.java)
            startActivity(intent)
        }
        val btnlistaLivro = findViewById<Button>(R.id.lista_livro)
        btnlistaLivro.setOnClickListener{
            Toast.makeText(this,"Você clicou na biblioteca de Livros.", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, ListaLivroActivity::class.java)
            startActivity(intent)
        }
        val btnlogin = findViewById<Button>(R.id.login_usuario)
        btnlogin.setOnClickListener{
            Toast.makeText(this,"Você clicou no Login.", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, ListaLivroActivity::class.java)
            startActivity(intent)
        }
    }
}

